package part_e;

/****************************************************************
 *
 * File: Main.java
 * By: Marty Martin
 * Date: 06/07/2024
 *
 * Description: Simple Hello World Program
 *
 ****************************************************************/
public class Main {
    public static void main(String[] args) {
        System.out.println("Hello World! Discussion Sections are here!!!");
        System.out.println("Course: CSC 220.01");
        System.out.println("Student: Marty Martin");
        System.out.println("Assignment #: 01");
        System.out.println("Due Date & Time: 06-10-2024 at 12:59 AM");
        System.out.println("SFSU's motto: 'Experientia Docet' means Experience Teaches");

    }
}
