package part_e;

public class DegreePlanner_3DArray_MartyMartin {
    public void display() {
        System.out.println("This is DegreePlanner_3DArray_MartyMartin in part_e.");
    }
}
